import React, { Component } from 'react'

class RobotForm extends Component {
    constructor(props){
    super(props)
    this.state={
        name:"",
        type:"",
        mass:""
    }

    this.ChangeType=(event)=>{
        this.setState({
            type:event.target.value
            });
    }
     this.ChangeName=(event)=>{
        this.setState({
            name:event.target.value
            });
    }
     this.ChangeMass=(event)=>{
        this.setState({
            mass:event.target.value
            });
    }
    }
    render() {
        return (
            <form>
                <input placeholder="Name" type="text" id="name" onChange={(event) => this.ChangeName(event)} value={this.state.name} />
                <input placeholder="Type" type="text" id="type" onChange={(event) => this.ChangeType(event)} value={this.state.type} />
                <input placeholder="Mass" type="text" id="mass" onChange={(event) => this.ChangeMass(event)} value={this.state.mass} />
                <button value="add" onClick={() => this.props.onAdd({name:this.state.name,type:this.state.type,mass:this.state.mass})} >Add</button>
            </form>
        )
    }
}

export default RobotForm